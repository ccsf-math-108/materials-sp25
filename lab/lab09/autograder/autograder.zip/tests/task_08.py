OK_FORMAT = True

test = {   'name': 'task_08',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(task_08, np.ndarray)\nTrue',
                                       'failure_message': '❌ task_08 should be an array.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_08 is an array.'},
                                   {   'code': '>>> set(task_08).issubset({1, 2, 3, 4})\nTrue',
                                       'failure_message': '❌ task_08 should be an array of numbers 1, 2, 3, or 4.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_08 is an array of numbers 1, 2, 3, or 4.'},
                                   {   'code': '>>> import hashlib\n'
                                               '>>> \n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness."""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> np.sort(list([get_hash(item) for item in task_08]))\n'
                                               "array(['a87ff679a2f3e71d9181a67b7542122c',\n"
                                               "       'c4ca4238a0b923820dcc509a6f75849b'],\n"
                                               "      dtype='<U32')",
                                       'failure_message': "❌ task_08 doesn't seem correct. Check your reasoning with a classmate, a tutor, or the instructor.",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_08 seems correct.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
