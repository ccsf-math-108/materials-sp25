OK_FORMAT = True

test = {   'name': 'task_13',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(left_end, (int, np.integer, float, np.float32, np.float64)) and isinstance(right_end, (int, np.integer, float, np.float32, '
                                               'np.float64))\n'
                                               'True',
                                       'failure_message': '❌ left_end and right_end should be numbers. Are you using the percentile function?',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ left_end and right_end are numbers.'},
                                   {   'code': '>>> 91 < left_end < 98\nTrue',
                                       'failure_message': "❌ left_end doesn't seem reasonable. If you find yourself using 5 and 95 as the arguments to `percentile`, try again - only 90% of the data "
                                                          'is between the 5th and 95th percentiles!',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ left_end seems reasonable.'},
                                   {   'code': '>>> 148 < right_end < 156\nTrue',
                                       'failure_message': "❌ right_end doesn't seem reasonable. If you find yourself using 5 and 95 as the arguments to `percentile`, try again - only 90% of the data "
                                                          'is between the 5th and 95th percentiles!',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ right_end seems reasonable.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
