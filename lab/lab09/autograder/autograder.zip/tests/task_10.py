OK_FORMAT = True

test = {   'name': 'task_10',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(task_10, (int, np.integer, float, np.float32, np.float64))\nTrue',
                                       'failure_message': '❌ task_10 should be assigned to a number. You should create an arithmetic expression that evaluates to the requested probability.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_10 is assigned to a number.'},
                                   {   'code': '>>> task_10 > 0.6\nTrue',
                                       'failure_message': '❌ task_10 should be above 60%. Consider the probability that at least one of the elements in our resample is equal to 135.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_10 is above 60%.'},
                                   {   'code': '>>> import hashlib\n'
                                               '>>> \n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness."""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> get_hash(round(task_10, 4))\n'
                                               "'a3242fb34ba60c6622307ace03134c74'",
                                       'failure_message': "❌ task_10 doesn't seem correct. If any one of the resampled values is 135, then the max of the resample will be 135.",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_10 seems correct.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
