OK_FORMAT = True

test = {   'name': 'task_03',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> set(task_03).issubset({1, 2, 3, 4, 5, 6})\nTrue',
                                       'failure_message': '❌ task_03 should be assigned to an integer 1, 2, 3, 4, 5, or 6.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_03 is assigned to an integer 1, 2, 3, 4, 5, or 6.'},
                                   {   'code': '>>> 3 not in task_03\nTrue',
                                       'failure_message': '❌ You should not select 3. If `N` is the max in the population, then it would be impossible for any sample from that population to have a '
                                                          'value larger than the population max.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ Good work not selecting 3.'},
                                   {   'code': '>>> import hashlib\n'
                                               '>>> \n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness."""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               ">>> get_hash(sum(task_03)) == '6f4922f45568161a8cdf4ad2299f6d23' and len(task_03) == 5\n"
                                               'True',
                                       'failure_message': "❌ task_03 doesn't seem correct.",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_03 seems correct!'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
