OK_FORMAT = True

test = {   'name': 'task_06',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(simulate_resample(), Table)\nTrue',
                                       'failure_message': '❌ Your simulate_resample function should return a Table. Make sure you have a return statement.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ Your simulate_resample function returns a Table.'},
                                   {   'code': '>>> one_resample\nserial_number\n108\n57\n57\n36\n41\n42\n47\n50\n135\n47\n... (7 rows omitted)',
                                       'failure_message': "❌ Your simulate_resample doesn't seem to be working correctly. You should be using .sample() with the observations table to create a "
                                                          'bootstrap resample.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ Your simulate_resample seems to be working correctly.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
