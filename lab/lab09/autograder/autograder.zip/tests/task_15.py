OK_FORMAT = True

test = {   'name': 'task_15',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> task_15 in {1, 2, 3, 4, 5}\nTrue',
                                       'failure_message': '❌ task_15 should be assigned to a number 1, 2, 3, 4, or 5.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_15 is assigned to a number 1, 2, 3, 4, or 5.'},
                                   {   'code': '>>> import hashlib\n'
                                               '>>> \n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness."""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> get_hash(task_15)\n'
                                               "'eccbc87e4b5ce2fe28308fd9f2a7baf3'",
                                       'failure_message': '❌ task_15 does not seem correct. How are you supposed to interpret 95% confidence?',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_15 seems correct.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
