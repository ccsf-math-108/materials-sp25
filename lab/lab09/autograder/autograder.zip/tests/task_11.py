OK_FORMAT = True

test = {   'name': 'task_11',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(example_estimates, np.ndarray) and len(example_estimates) == 10000\nTrue',
                                       'failure_message': '❌ example_estimates is not an array with the correct number of items. Your simulate_estimates function should return an array should have '
                                                          'the same number of items as the value repetitions.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ example_estimates is an array with the correct number of items.'},
                                   {   'code': '>>> np.random.seed(123)\n'
                                               ">>> og_tbl = Table().with_column('serial_number', np.arange(1, 1000 + 1))\n"
                                               '>>> samp_size = 50\n'
                                               '>>> reps = 1000\n'
                                               '>>> stat = calculate_mean_based_estimate\n'
                                               '>>> example_mean_estimates = simulate_estimates(og_tbl, samp_size, stat, reps)\n'
                                               '>>> np.isclose(np.sum(example_mean_estimates), 1000825.424)\n'
                                               'False',
                                       'failure_message': "❌ simulate_estimates doesn't seem to work correctly for the mean-based estimate function. Make sure your function accepts a function name "
                                                          '(statistic) as an input and you use the name statistic to calculate the statistic of the resample.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ simulate_estimates seems to work correctly for the mean-based estimate function.'},
                                   {   'code': '>>> np.random.seed(123)\n'
                                               ">>> og_tbl = Table().with_column('serial_number', np.arange(1, 1000 + 1))\n"
                                               '>>> samp_size = 50\n'
                                               '>>> reps = 1000\n'
                                               '>>> stat = calculate_max_based_estimate\n'
                                               '>>> example_max_estimates = simulate_estimates(og_tbl, samp_size, stat, reps)\n'
                                               '>>> np.isclose(np.sum(example_max_estimates), 999369.0)\n'
                                               'False',
                                       'failure_message': "❌ simulate_estimates doesn't seem to work correctly for the max-based estimate function. Make sure your function accepts a function name "
                                                          '(statistic) as an input and you use the name statistic to calculate the statistic of the resample.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ simulate_estimates seems to work correctly for the max-based estimate function.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
