OK_FORMAT = True

test = {   'name': 'task_05',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> isinstance(mean_based_estimate, (int, np.integer, float, np.float32, np.float64))\nTrue',
                                       'failure_message': '❌ mean_based_estimate should be a number. Make sure your function is returning 2 times the mean of nums.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ mean_based_estimate is a number.'},
                                   {'code': '>>> np.isclose(mean_based_estimate, 122.47058823529412)\nTrue', 'failure_message': '❌ ', 'hidden': False, 'locked': False, 'success_message': '✅ '}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
