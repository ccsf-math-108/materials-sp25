OK_FORMAT = True

test = {   'name': 'task_04',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> test_max = calculate_max_based_estimate(np.array([1, 2, 3]))\n>>> test_max == 3\nTrue',
                                       'failure_message': "❌ calculate_max_based_estimate doesn't seem to be working. You should use the max function and return the max value from nums.",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ calculate_max_based_estimate seems to be working.'},
                                   {   'code': '>>> isinstance(max_based_estimate, (int, np.integer, float, np.float32, np.float64))\nTrue',
                                       'failure_message': '❌ max_based_estimate. Make sure your function is returning the max of nums.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ max_based_estimate is a number.'},
                                   {   'code': ">>> max_based_estimate in observations.column('serial_number')\nTrue",
                                       'failure_message': '❌ max_based_estimate should be a serial number in the sample. When calling the function, replace nums with an array of the sampled serial '
                                                          'numbers.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ max_based_estimate is a serial number in the sample.'},
                                   {   'code': '>>> import hashlib\n'
                                               '>>> \n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness."""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> get_hash(max_based_estimate)\n'
                                               "'7f1de29e6da19d22b51c68001e7e0e54'",
                                       'failure_message': "❌ max_based_estimate does not seem correct. Call your function on the column 'serial_number' from the observations table.",
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ max_based_estimate seems correct.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
