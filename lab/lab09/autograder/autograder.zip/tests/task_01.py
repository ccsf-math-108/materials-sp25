OK_FORMAT = True

test = {   'name': 'task_01',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> task_01 in {1, 2, 3, 4}\nTrue',
                                       'failure_message': '❌ task_01 should be assigned to an integer 1, 2, 3, or 4.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_01 was assigned to an integer 1, 2, 3, or 4.'},
                                   {   'code': '>>> import hashlib\n'
                                               '>>> \n'
                                               '>>> def get_hash(num):\n'
                                               '...     """Helper function for assessing correctness."""\n'
                                               '...     return hashlib.md5(str(num).encode()).hexdigest()\n'
                                               '>>> get_hash(task_01)\n'
                                               "'c81e728d9d4c2f636f067f89cc14862c'",
                                       'failure_message': '❌ task_01 was not assigned to the correct integer.',
                                       'hidden': False,
                                       'locked': False,
                                       'success_message': '✅ task_01 was assigned to the correct integer.'}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
